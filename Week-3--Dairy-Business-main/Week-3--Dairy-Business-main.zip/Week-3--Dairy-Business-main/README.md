# Week-3--Dairy-Business
#### This is a website for taking inventory of a a dairy farm
#### By **Roy Masai**
The project is about automation of an agriculture farm's milk production and sales inventory.




## Installation

Clone the repository

```bash
git clone https://github.com/Masai11/Week-3--Dairy-Business.git
```

## Usage

Open the index.html file on a browser 


## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.
reach me through this email roy.kiplagat@student.moringaschool.com
## License
[MIT](https://choosealicense.com/licenses/mit/)
